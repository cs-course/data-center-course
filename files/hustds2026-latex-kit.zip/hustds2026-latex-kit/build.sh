#!/usr/bin/env bash
# ============================================================
#  HUSTDS 2026 模板包 · macOS / Linux 一键编译
#  用法：./build.sh            （默认编 paper/hustds2026-paper.tex）
#        ./build.sh path/to/x.tex
#  需要：TeX Live / MacTeX，xelatex 在 PATH 中
# ============================================================
set -euo pipefail

TEXFILE="${1:-hustds2026-paper.tex}"
BASE="${TEXFILE%.tex}"

if ! command -v xelatex >/dev/null 2>&1; then
  echo "找不到 xelatex。先装 TeX Live / MacTeX，见 01-环境搭建.md" >&2
  exit 1
fi

echo "[1/3] 第一次编译"
xelatex -interaction=nonstopmode -halt-on-error "$TEXFILE" >/dev/null || {
  echo "编译失败，下面是日志尾部：" >&2
  tail -n 30 "${BASE}.log" >&2
  exit 1
}

echo "[2/3] 第二次编译"
xelatex -interaction=nonstopmode -halt-on-error "$TEXFILE" >/dev/null || {
  echo "编译失败，下面是日志尾部：" >&2
  tail -n 30 "${BASE}.log" >&2
  exit 1
}

echo "[3/3] 清理中间文件"
rm -f "${BASE}.aux" "${BASE}.log" "${BASE}.out" "${BASE}.toc"

echo "完成：${BASE}.pdf"
