# 放图的地方

## 怎么生成

| 图从哪来 | 做法 | 输出 |
| :--- | :--- | :--- |
| 实验数据 | matplotlib / gnuplot | `fig.savefig('fig1-xxx.pdf')` |
| 结构图、流程图 | TikZ 直接写在 `.tex` 里（见 `../../example` 图 1） | 无外部文件 |
| 画的框图 | draw.io / PowerPoint 导出 **PDF** | 矢量 |
| 截图（不得已） | 至少 300 dpi PNG，**裁掉**标签栏、用户名、路径 | 位图 |

**不要**把网页截图、终端截图、Jupyter 输出直接放进去。这三类几乎必然带着
浏览器标签、`C:\Users\你的名字\`、主机名——一处就够判匿名泄漏。

## matplotlib 中文与尺寸

```python
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei']        # macOS 用 'Songti SC'，Linux 用 'Noto Sans CJK SC'
plt.rcParams['axes.unicode_minus'] = False          # 负号显示为方框时加这行
plt.rcParams['font.size'] = 9                       # 与正文五号字协调

fig, ax = plt.subplots(figsize=(4, 2.6))            # 4 英寸 ≈ 半栏；整栏约 6.6 英寸
# ... 画图 ...
fig.tight_layout()
fig.savefig('fig1-p99.pdf')                         # 存 PDF；PNG 至少 dpi=300
```

尺寸先定好再画。先画再看能不能塞进版面，通常要塞三次。

## 命名与引用

- 文件名：`fig1-p99.pdf`、`fig2-arch.pdf` —— 编号 + 内容，别用 `图1.pdf`（中文文件名在某些工具链下会出问题）。
- 放在本目录，正文用**相对路径**引用：`figures/fig1-p99.pdf`。
- 不要写绝对路径（换机器变红框），不要用空格和中文。

## 常见问题

| 现象 | 原因 | 处置 |
| :--- | :--- | :--- |
| 中文变方框 | 没设字体，或字体名写错 | 见上面的 `rcParams`；用 `fc-list`（Linux/mac）确认字体名 |
| 图太糊 | 存了 PNG 且 dpi 低 | 改存 PDF |
| 图片显示红框 | 路径错、缺扩展名、文件名有空格 | 检查 `\includegraphics{figures/xxx.pdf}` |
| 图超出页宽 | `width` 太大 | `width=0.8\linewidth` 或改小 |
| 图跑到页首/页尾 | 用了 `figure` 浮动环境 | 用模板的 `center + minipage + \captionof` 写法 |
