@echo off
REM ============================================================
REM  HUSTDS 2026 模板包 · Windows 一键编译
REM  用法：在任意 .tex 所在目录双击，或命令行 build.cmd ..\paper\hustds2026-paper.tex
REM  需要：TeX Live 或 MiKTeX（已在 PATH 中）
REM ============================================================
setlocal
set TEXFILE=%~1
if "%TEXFILE%"=="" set TEXFILE=hustds2026-paper.tex

echo [1/3] 第一次编译（生成 .aux，交叉引用此时还是 ??）
xelatex -interaction=nonstopmode -halt-on-error "%TEXFILE%"
if errorlevel 1 goto :fail

echo [2/3] 第二次编译（填好 \ref \cite 的编号）
xelatex -interaction=nonstopmode -halt-on-error "%TEXFILE%"
if errorlevel 1 goto :fail

echo [3/3] 清理中间文件
del /q "%~dpn1.aux" "%~dpn1.log" "%~dpn1.out" "%~dpn1.toc" 2>nul

echo.
echo 完成：%~dpn1.pdf
goto :eof

:fail
echo.
echo 编译失败。看 %~dpn1.log 的最后 30 行——错误通常在最上面那行 error 之前就已经发生。
exit /b 1
