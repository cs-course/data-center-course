#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""交稿前自检：页数、匿名、PDF 元数据。

用法：
  python tools/check_submission.py --pdf my-paper.pdf
  python tools/check_submission.py --pdf a.pdf b.pdf
  python tools/check_submission.py --dir .            # 批量

依赖：pip install pymupdf

判定：
  FAIL  硬性不合规，必须改（页数、学号、邮箱、元数据署名）
  WARN  疑似匿名泄漏，自己确认（姓名命中、「我们组」、致谢/基金字样）
  OK    通过

注意：这是机器初筛，不是评审。它查不出的泄漏（图里的用户名、截图里的路径）比你查出来的更多，
自查表才是主，脚本只是兜底。
"""

import argparse
import csv
import glob
import json
import os
import re
import sys

try:
    import pymupdf as fitz
except ImportError:
    try:
        import fitz  # 旧版 PyMuPDF
    except ImportError:
        sys.exit("缺依赖：pip install pymupdf")

CN_ID = re.compile(r"[MmDd]?\d{9,12}")
EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+")
FUND_WORDS = ["致谢", "基金", "资助", "国家自然科学基金", "NSFC", "重点研发计划", "项目编号", "基金号"]
SELF_WORDS = ["我们组", "本课题组", "我们实验室", "本实验室", "笔者所在"]


def load_names(roster_path):
    if not roster_path or not os.path.exists(roster_path):
        return []
    with open(roster_path, newline="", encoding="utf-8-sig") as f:
        return [r["name"].strip() for r in csv.DictReader(f) if r.get("name", "").strip()]


def check_pdf(path, names, min_pages, max_pages):
    res = {"file": os.path.basename(path), "fail": [], "warn": [], "pages": 0, "meta": {}}
    try:
        doc = fitz.open(path)
    except Exception as e:
        res["fail"].append(f"无法打开 PDF：{e}")
        return res

    res["pages"] = doc.page_count
    if doc.is_encrypted:
        res["fail"].append("PDF 已加密，评审无法打开")
    if not (min_pages <= doc.page_count <= max_pages):
        res["fail"].append(f"页数 {doc.page_count}，要求 {min_pages}–{max_pages}")

    meta = doc.metadata or {}
    res["meta"] = {k: meta.get(k, "") for k in ("author", "title", "subject", "keywords")}
    for field in ("author", "title", "subject", "keywords"):
        val = (meta.get(field) or "").strip()
        if val and any(n and n in val for n in names):
            res["fail"].append(f"PDF 元数据 {field} 含作者姓名：{val[:40]}")
    author_meta = (meta.get("author") or "").strip()
    if author_meta:
        res["warn"].append(f"PDF 元数据 author 非空（{author_meta[:30]}），投稿版应清空")
    title_meta = (meta.get("title") or "").strip()
    if title_meta and title_meta.lower().endswith(".tex"):
        res["warn"].append(f"PDF 标题是文件名（{title_meta}）——没设 \\title 或用了 pdfLaTeX 的残留")

    text = "\n".join(page.get_text() for page in doc)
    doc.close()

    hits = [h for h in CN_ID.findall(text)
            if re.fullmatch(r"[MmDd]\d{9,12}", h) or (h.isdigit() and len(h) >= 9)]
    if hits:
        res["fail"].append(f"正文出现疑似学号：{', '.join(sorted(set(hits))[:5])}")

    mails = sorted(set(EMAIL.findall(text)))
    if mails:
        res["fail"].append(f"正文出现邮箱：{', '.join(mails[:3])}")

    for w in SELF_WORDS:
        if w in text:
            res["warn"].append(f"出现可识别表述「{w}」")
    fund_hits = [w for w in FUND_WORDS if w in text]
    if fund_hits:
        res["warn"].append(f"出现致谢/基金类字样：{'、'.join(fund_hits)}（投稿版必须删）")

    name_hits = sorted({n for n in names if n in text})
    if name_hits:
        res["warn"].append(f"正文出现与同学同名者：{', '.join(name_hits[:5])}（可能是文献作者，请确认）")

    return res


def run(paths, names, min_pages, max_pages):
    results = []
    for p in paths:
        r = check_pdf(p, names, min_pages, max_pages)
        results.append(r)
        status = "FAIL" if r["fail"] else ("WARN" if r["warn"] else "OK")
        print(f"[{status}] {r['file']}  {r['pages']} 页")
        for m in r["fail"]:
            print("   ✗", m)
        for m in r["warn"]:
            print("   !", m)
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pdf", nargs="*", default=[])
    ap.add_argument("--dir", default=None, help="批量检查目录下所有 PDF")
    ap.add_argument("--roster", default=None, help="可选：含 name 列的 CSV，用于姓名比对")
    ap.add_argument("--min-pages", type=int, default=4)
    ap.add_argument("--max-pages", type=int, default=6)
    ap.add_argument("--json", default=None)
    args = ap.parse_args()

    paths = list(args.pdf)
    if args.dir:
        paths += sorted(glob.glob(os.path.join(args.dir, "*.pdf")))
    if not paths:
        raise SystemExit("给 --pdf 或 --dir")

    results = run(paths, load_names(args.roster), args.min_pages, args.max_pages)

    n_fail = sum(1 for r in results if r["fail"])
    n_warn = sum(1 for r in results if r["warn"] and not r["fail"])
    print(f"\n共 {len(results)} 份：{n_fail} 份不合规，{n_warn} 份需人工确认")
    print("自查表在 03-写作规范.md 末节，脚本过的项不代表没问题。")

    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"结果写入 {args.json}")

    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
