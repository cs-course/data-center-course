# 04 · LaTeX 速查

写的时候放手边，复制粘贴用。**不需要通读**，按需要跳。

---

## 0. 编译

```bash
xelatex my-paper.tex              # 编一遍（先跑一次，看有没有报错）
xelatex my-paper.tex              # 再编一遍（填 \ref \cite 的编号）
latexmk my-paper.tex              # 或用 latexmk，自动连编（读 latexmkrc）
latexmk -c                        # 清理中间文件
```

- 必须 **XeLaTeX**。`pdflatex` 编 ctex 文档会得到一堆警告和半空白页。
- 必须 **两遍**。第一遍 `\ref` 是 `??`、`\cite` 是 `[?]`，属正常。
- 报错先看 `.log`：从**最后一个** `!` 往上找，真正的错误常在上面几行。

---

## 1. 文档骨架

```latex
% !TeX program = xelatex
\documentclass[a4paper,zihao=5,fontset=windows]{ctexart}  % mac: fontset=mac；Linux/Overleaf: fandol
\usepackage[top=2.5cm,bottom=2.5cm,left=2.2cm,right=2.2cm]{geometry}
\usepackage{booktabs,graphicx,caption,amsmath,array,tabularx,enumitem,url}
\begin{document}
  ……
\end{document}
```

`zihao=5` 是五号字（10.5 pt），课程要求。改它等于改字号，违规。

---

## 2. 章节与段落

```latex
\section{引言}            % 1 引言
\subsection{分类维度}      % 2.1 分类维度
\subsubsection{可选}       % 2.1.1（一般用不到，4–6 页的稿子两层够了）
\paragraph{小标题}         % 行内小标题，不编号

空一行 = 新段落（首行自动缩进 2 字符，不要手动打空格）
\\ 只在表格/居中环境里用；正文里用它换行是错误的
\noindent 不缩进          % 摘要、关键词段落用
\textbf{加粗} \emph{强调} \underline{下划线} \texttt{等宽}
\footnote{脚注}           % 少用，脚注占页
```

不要手打「1. 引言」这种编号——用 `\section`，否则改结构时全要重编。

---

## 3. 三线表（最常用，务必掌握）

```latex
\begin{center}
\begin{minipage}{\linewidth}
  \centering
  \captionof{table}{表题在表上方，能独立读懂}   % 表题 + 编号
  \label{tab:framework}
  \begin{tabular}{>{\raggedright\arraybackslash}p{2.2cm}>{\raggedright\arraybackslash}p{5.4cm}>{\raggedright\arraybackslash}p{5.6cm}}
    \toprule
    \textbf{层次} & \textbf{典型来源} & \textbf{可观测信号} \\
    \midrule
    排队 & 请求排队、批处理合并 & P99 与并发度 \\
    服务放大 & GC、compaction、重建 & 长尾分布的周期性 \\
    \bottomrule
  \end{tabular}
\end{minipage}
\end{center}
```

为什么这么写：

- `minipage`：既不浮动（位置就在你写的地方），又不会把表题和表格拆到两页。
- `>{\raggedright\arraybackslash}p{..}`：定宽列 + 左对齐。只用 `p{..}` 会两端对齐，中文会被拉出巨大空隙。
- `\captionof` 而不是 `\caption`：因为没用 `table` 浮动体，需要 `caption` 宏包提供这个命令。
- 三线表只要 `\toprule` `\midrule` `\bottomrule`，**不要竖线和方格**。

**跨列**（合并单元格）：

```latex
\multicolumn{2}{c}{合并两列} & 第三列 \\
```

**整行加粗的合计行**：

```latex
\midrule
\textbf{合计} & \textbf{—} & \textbf{100\%} \\
\bottomrule
```

**长表跨页**（4–6 页基本用不到，知道有这回事即可）：改用 `longtable` 环境。

---

## 4. 图

```latex
\begin{center}
\begin{minipage}{\linewidth}
  \centering
  \includegraphics[width=0.8\linewidth]{figures/fig1-p99.pdf}
  \captionof{figure}{图题在图下方，说明画的是什么，不写「示意图」}
  \label{fig:p99}
\end{minipage}
\end{center}
```

- 路径用**相对路径**，图片放 `figures/` 目录；别写 `C:\Users\...`（换机器就红框，还会泄漏路径）。
- 扩展名写全：`.pdf` 或 `.png`。矢量图缩放不失真，优先 PDF。
- `width=0.8\linewidth`：图宽随版面走。想更小改 `0.6`，别用 `scale=0.5`（不随版面自适应）。

**并排两图**（省页数的利器）：

```latex
\begin{center}
\begin{minipage}{0.48\linewidth}
  \centering
  \includegraphics[width=\linewidth]{figures/fig-a.pdf}
  \captionof{figure}{(a) 吞吐随并发度变化}
  \label{fig:a}
\end{minipage}\hfill
\begin{minipage}{0.48\linewidth}
  \centering
  \includegraphics[width=\linewidth]{figures/fig-b.pdf}
  \captionof{figure}{(b) P99 随上下文长度变化}
  \label{fig:b}
\end{minipage}
\end{center}
```

（严格做法是用 `subcaption` 宏包的 `subfigure`，但两个 `minipage` 更省事、不会出现编号错乱。）

**TikZ 画结构图**：见 `example/hustds2026-example.tex` 的图 1，改文字直接用。

---

## 5. 公式

```latex
行内：设单 token 的 KV 体积为 $S$ 字节，上下文长度为 $C$。

行间（编号）：
\begin{equation}
  B_{\text{req}} = \frac{S \cdot C}{T}
  \label{eq:bw}
\end{equation}
由式~\eqref{eq:bw} 可知……

行间（不编号）：\[ ... \] 或 \begin{equation*} ... \end{equation*}

多行对齐：
\begin{align}
  a &= b + c \\
  d &= e + f
\end{align}

常用符号：\times \approx \leq \geq \gg \ll \cdot \sum \prod \alpha \beta \Delta
正体下标：$T_{\text{prefill}}$   （不要写成 $T_{prefill}$，会变成斜体变量相乘）
千分位：\num 需要 siunitx，本模板未装，直接写 87\,GB/s
```

`\,` 是细空格，数字与单位之间用它（`87\,GB/s` 比 `87GB/s` 好看，也是排版惯例）。

---

## 6. 列表

```latex
\begin{itemize}[nosep]
  \item 第一条
  \item 第二条
\end{itemize}

\begin{enumerate}[label=(\arabic*),nosep]
  \item 第一条
  \item 第二条
\end{enumerate}

\begin{enumerate}[label=\textbf{（\chinese*）},nosep]   % （一）（二）
```

`[nosep]` 压缩行距，4–6 页的稿子里很有用。列表超过两项考虑改成表格或段落——列表写多了像 PPT。

---

## 7. 交叉引用与参考文献

```latex
\label{tab:x}  \label{fig:y}  \label{eq:z}     % 先定义
\ref{tab:x}    \ref{fig:y}    \eqref{eq:z}     % 再引用
```

规则：`\label` 放在 `\captionof` **之后**（这样引用到的是表格号，不是节号）；
正文里写「如表~\ref{tab:x} 所示」，`~` 是不换行空格，防止「表」和编号分居两行。

引用文献：

```latex
……如 PagedAttention~\cite{ref1} 所示。
……已有工作~\cite{ref4,ref5,ref6} 分别从三个角度处理该问题。
```

文末：

```latex
\begin{thebibliography}{99}
  \bibitem{ref1} 作者A, 作者B. 标题[C]//会议名. 出版地: 出版者, 2026: 1-16.
\end{thebibliography}
```

`\bibitem{ref1}` 里的 `ref1` 就是 `\cite{ref1}` 的 key，自己起名（建议 `作者年份`，如 `kwon2023paged`）。
顺序按**正文首次引用**排，不是字母序（GB/T 7714 顺序编码制）。

---

## 8. 版面微调（压页数用，别乱改）

```latex
\small                     % 局部缩小（只对小表用）
\vspace{-4pt}              % 局部收紧
\begin{center} ... \end{center}   % 居中块，两边会吃掉一点空白
```

**不要**改：`\zihao`、`geometry` 的边距、`\linespread`、`\renewcommand{\baselinestretch}`。
评审一眼看得出，且属于格式违规。

---

## 9. 特殊字符：这些必须转义

| 想显示 | 写法 | 说明 |
| :--- | :--- | :--- |
| `%` | `\%` | 不转义会把后面整行变注释 |
| `&` | `\&` | 在 tabular 里还是列分隔符 |
| `_` | `\_` | 不转义会报 `Missing $ inserted` |
| `#` | `\#` | |
| `$` | `\$` | |
| `{` `}` | `\{` `\}` | |
| `~` | `\textasciitilde` | |
| `^` | `\textasciicircum` | |
| `\` | `\textbackslash` | |
| 空格 | `\ ` 或 `~` | 普通空格会被吞，用 `\ ` 强制 |

中文标点直接用全角，不要用 `` ` `` 或 `'` 拼引号。

---

## 10. 报错对照表

| 报错 | 真正的原因 | 怎么改 |
| :--- | :--- | :--- |
| `! Undefined control sequence` | 命令拼错，或没 `\usepackage` | 看报错行号上那个命令；缺包就加宏包 |
| `! Missing $ inserted` | 数学符号（`_ ^ &`）写在了文本模式 | 加 `$...$`，或把 `_` 改成 `\_` |
| `! LaTeX Error: File 'xxx.sty' not found` | 缺宏包 | `tlmgr install xxx` / MiKTeX 自动装 |
| `! Package fontspec Error: The font "SimSun" cannot be found` | `fontset` 与系统不匹配 | mac 改 `mac`，Linux/Overleaf 改 `fandol` |
| `! LaTeX Error: Environment xxx undefined` | 环境名拼错，或没加载宏包 | 检查 `\begin{xxx}` 拼写 |
| `! File ended while scanning use of \xxx` | 环境没关（少了 `\end{...}`） | 从文件末尾往前数 `\begin` 与 `\end` 是否配平 |
| `! Argument of \xxx has an extra }` | 花括号不配对 | 数括号；常见于 `\textbf{...` 少写右括号 |
| `! LaTeX Error: Something's wrong--perhaps a missing \item` | 在列表/文献环境外用了 `\item` | 补 `\begin{itemize}`，或删掉多余的 `\item` |
| `Overfull \hbox (xx pt too wide)` | 某行/表/图超出页宽 | 表格减列或改 `p{}` 定宽；图改小 `width` |
| `Underfull \hbox (badness 10000)` | 排版拉伸，难看但能出 PDF | 通常可忽略；表格文字用 `\raggedright` 解决 |
| `Citation 'xxx' undefined` | 编了一遍，或 key 拼错 | 再编一遍；仍报就核对 `\bibitem` 的 key |
| `Reference 'xxx' undefined` | 同上 | 再编一遍 |
| `! Emergency stop` | 严重语法错误（多半是缺少 `\end{document}` 或括号大乱） | 看 `.log` 第一个 `!` 的位置 |
| 中文变空白 / 一堆 `Missing character` | 用了 pdfLaTeX | 换 XeLaTeX |
| 图片显示红框 | 路径错、缺扩展名、文件名含空格 | 改相对路径 `figures/x.pdf` |

**读日志的正确姿势**：用 `xelatex -file-line-error` 编译，报错会写成
`./my-paper.tex:42: Undefined control sequence.` —— 直接跳到第 42 行。

---

## 11. 从 Word / 网页搬内容的坑

- **智能引号**：Word 的 `“ ”` 粘进 LaTeX 会变成乱码，替换成全角 `“”` 或删掉。
- **全角空格与制表符**：粘贴后多出一堆看不见的空格，导致行首缩进错乱（`\hspace` 报错）。用编辑器的「显示空白字符」检查。
- **公式**：Word 公式粘不进 LaTeX，必须手写；别指望转换工具，转换质量比手写慢。
- **项目符号**：Word 的 `•` 粘进来是特殊字符，改成 `itemize`。
- **表格**：Word 表格粘进来是 `&` 和 `\\` 的乱码，老老实实重写成 `tabular`。
- **图片**：Word 里的图是嵌入的位图，得从原图重新导出 PDF，否则放大就糊。

一句话：**内容可以搬，格式必须重排**。搬内容 10 分钟，修格式 2 小时——所以别整篇复制，按节搬。
